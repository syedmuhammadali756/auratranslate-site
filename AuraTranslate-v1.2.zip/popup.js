// ═══════════════════════════════════════════════════════════════
// AuraTranslate AI — Premium Popup Script
// ═══════════════════════════════════════════════════════════════

// DOM Elements
const inputText = document.getElementById('inputText');
const translateBtn = document.getElementById('translateBtn');
const clearBtn = document.getElementById('clearBtn');
const copyBtn = document.getElementById('copyBtn');
const swapBtn = document.getElementById('swapBtn');
const resultDiv = document.getElementById('result');
const resultText = document.getElementById('resultText');
const loadingIndicator = document.getElementById('loadingIndicator');
const charCounter = document.getElementById('charCounter');

// Notepad Elements
const notepadText = document.getElementById('notepadText');
const wordCount = document.getElementById('wordCount');
const noteCharCount = document.getElementById('noteCharCount');
const savedIndicator = document.getElementById('savedIndicator');

// Tone & Ad Elements
const toneCards = document.querySelectorAll('.tone-card');
const adContainer = document.getElementById('adContainer');
const closeAdBtn = document.getElementById('closeAdBtn');
const adClickArea = document.getElementById('adClickArea');

let lastTranslation = null;
let currentTone = 'Casual';
let saveTimer = null;

// ═══════════════════════════════════════════════════════════════
// TAB SWITCHING — with smooth animation
// ═══════════════════════════════════════════════════════════════
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        const tabName = tab.getAttribute('data-tab');

        // Update active tab
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        // Update active content with animation
        document.querySelectorAll('.tab-content').forEach(tc => {
            tc.classList.remove('active');
        });
        const target = document.getElementById(tabName);
        if (target) {
            target.classList.add('active');
        }
    });
});

// ═══════════════════════════════════════════════════════════════
// CHARACTER COUNTER
// ═══════════════════════════════════════════════════════════════
inputText.addEventListener('input', () => {
    const len = inputText.value.length;
    const max = 2000;
    charCounter.textContent = `${len} / ${max}`;
    charCounter.classList.remove('warning', 'danger');
    if (len > max * 0.9) {
        charCounter.classList.add('danger');
    } else if (len > max * 0.7) {
        charCounter.classList.add('warning');
    }
});

// ═══════════════════════════════════════════════════════════════
// TONE SELECTION
// ═══════════════════════════════════════════════════════════════
toneCards.forEach(card => {
    card.addEventListener('click', () => {
        toneCards.forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        currentTone = card.getAttribute('data-tone');
        chrome.storage.local.set({ 'selectedTone': currentTone });
    });
});

// Load saved tone
chrome.storage.local.get(['selectedTone'], (result) => {
    if (result.selectedTone) {
        currentTone = result.selectedTone;
        toneCards.forEach(c => {
            c.classList.toggle('active', c.getAttribute('data-tone') === currentTone);
        });
    }
});

// ═══════════════════════════════════════════════════════════════
// TRANSLATION LOGIC
// ═══════════════════════════════════════════════════════════════
translateBtn.addEventListener('click', async () => {
    const text = inputText.value.trim();

    if (!text) {
        shakeElement(inputText);
        return;
    }

    // Show loading
    translateBtn.disabled = true;
    loadingIndicator.classList.add('visible');
    resultDiv.classList.remove('visible');

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'translate',
            text: text,
            direction: 'auto',
            tone: currentTone
        });

        if (response.success) {
            resultText.textContent = response.translated;
            resultDiv.classList.add('visible');
            lastTranslation = response;

            // Save to history
            saveToHistory(text, response.translated, currentTone);
        } else {
            showToast('Translation failed: ' + response.error);
        }
    } catch (error) {
        showToast('Error: ' + error.message);
    } finally {
        translateBtn.disabled = false;
        loadingIndicator.classList.remove('visible');
    }
});

// Ctrl+Enter shortcut
inputText.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'Enter') {
        translateBtn.click();
    }
});

// ═══════════════════════════════════════════════════════════════
// RESULT ACTIONS
// ═══════════════════════════════════════════════════════════════
clearBtn.addEventListener('click', () => {
    inputText.value = '';
    resultDiv.classList.remove('visible');
    lastTranslation = null;
    charCounter.textContent = '0 / 2000';
    charCounter.classList.remove('warning', 'danger');
    inputText.focus();
});

copyBtn.addEventListener('click', async () => {
    try {
        await navigator.clipboard.writeText(resultText.textContent);
        showToast('Copied to clipboard!');
        // Visual feedback on icon
        copyBtn.style.color = '#34d399';
        setTimeout(() => { copyBtn.style.color = ''; }, 1500);
    } catch (error) {
        showToast('Failed to copy');
    }
});

swapBtn.addEventListener('click', () => {
    if (lastTranslation) {
        inputText.value = lastTranslation.translated;
        resultDiv.classList.remove('visible');
        // Trigger char counter update
        inputText.dispatchEvent(new Event('input'));
        translateBtn.click();
    }
});

// ═══════════════════════════════════════════════════════════════
// NOTEPAD LOGIC
// ═══════════════════════════════════════════════════════════════
chrome.storage.local.get(['notepadContent'], (result) => {
    if (result.notepadContent) {
        notepadText.value = result.notepadContent;
        updateNotepadStats();
    }
});

notepadText.addEventListener('input', () => {
    updateNotepadStats();

    // Debounced save
    clearTimeout(saveTimer);
    savedIndicator.classList.remove('visible');
    saveTimer = setTimeout(() => {
        chrome.storage.local.set({ 'notepadContent': notepadText.value });
        savedIndicator.classList.add('visible');
        setTimeout(() => savedIndicator.classList.remove('visible'), 2000);
    }, 500);
});

function updateNotepadStats() {
    const text = notepadText.value;
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    const chars = text.length;
    wordCount.textContent = `${words} word${words !== 1 ? 's' : ''}`;
    noteCharCount.textContent = `${chars} char${chars !== 1 ? 's' : ''}`;
}

// ═══════════════════════════════════════════════════════════════
// AD BANNER
// ═══════════════════════════════════════════════════════════════
adClickArea.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://topkitchenremodelingtacoma.com/' });
});

closeAdBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    adContainer.style.display = 'none';
    setTimeout(() => {
        adContainer.style.display = 'flex';
    }, 60000);
});

// ═══════════════════════════════════════════════════════════════
// HISTORY
// ═══════════════════════════════════════════════════════════════
let translationHistory = [];

loadHistory();

function loadHistory() {
    chrome.storage.local.get(['history'], (result) => {
        if (result.history) {
            translationHistory = result.history;
            displayHistory();
        }
    });
}

function saveToHistory(original, translated, tone) {
    const entry = {
        original,
        translated,
        tone,
        timestamp: Date.now()
    };

    translationHistory.unshift(entry);
    if (translationHistory.length > 50) {
        translationHistory = translationHistory.slice(0, 50);
    }

    chrome.storage.local.set({ history: translationHistory });
    displayHistory();
}

function displayHistory() {
    const historyList = document.getElementById('historyList');
    if (!historyList) return;

    if (translationHistory.length === 0) {
        historyList.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
                </svg>
                <p>No translations yet</p>
            </div>`;
        return;
    }

    historyList.innerHTML = translationHistory.map((entry, index) => {
        const time = new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const date = new Date(entry.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' });
        return `
            <div class="history-item">
                <div class="history-original">${escapeHtml(entry.original)}</div>
                <div class="history-translated">${escapeHtml(entry.translated)}</div>
                <div class="history-meta">
                    <div>
                        <span class="history-tone-badge">${entry.tone}</span>
                        <span class="history-info" style="margin-left:8px;">${date} ${time}</span>
                    </div>
                    <div class="history-actions">
                        <button class="btn-icon" onclick="copyHistoryItem(${index})" title="Copy">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                            </svg>
                        </button>
                        <button class="btn-icon" onclick="deleteHistoryItem(${index})" title="Delete">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>`;
    }).join('');
}

// Global functions for history item actions
window.copyHistoryItem = async function (index) {
    try {
        await navigator.clipboard.writeText(translationHistory[index].translated);
        showToast('Copied!');
    } catch (e) {
        showToast('Failed to copy');
    }
};

window.deleteHistoryItem = function (index) {
    translationHistory.splice(index, 1);
    chrome.storage.local.set({ history: translationHistory });
    displayHistory();
};

document.getElementById('clearHistoryBtn')?.addEventListener('click', () => {
    if (confirm('Clear all translation history?')) {
        translationHistory = [];
        chrome.storage.local.set({ history: [] });
        displayHistory();
    }
});

// ═══════════════════════════════════════════════════════════════
// SETTINGS TOGGLES
// ═══════════════════════════════════════════════════════════════
document.querySelectorAll('.toggle').forEach(toggle => {
    toggle.addEventListener('click', () => {
        toggle.classList.toggle('active');
        const settingId = toggle.id;
        const isActive = toggle.classList.contains('active');
        chrome.storage.local.set({ [settingId]: isActive });
    });
});

// Load saved settings
chrome.storage.local.get(['autoTranslateToggle', 'historyToggle', 'floatingBtnToggle'], (result) => {
    if (result.autoTranslateToggle !== undefined) {
        document.getElementById('autoTranslateToggle').classList.toggle('active', result.autoTranslateToggle);
    }
    if (result.historyToggle !== undefined) {
        document.getElementById('historyToggle').classList.toggle('active', result.historyToggle);
    }
    if (result.floatingBtnToggle !== undefined) {
        document.getElementById('floatingBtnToggle').classList.toggle('active', result.floatingBtnToggle);
    }
});

// ═══════════════════════════════════════════════════════════════
// UTILITIES
// ═══════════════════════════════════════════════════════════════
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message) {
    // Create floating toast
    const existing = document.querySelector('.aura-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'aura-toast';
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 50px;
        left: 50%;
        transform: translateX(-50%) translateY(10px);
        background: rgba(255,255,255,0.95);
        color: #0d0d1a;
        padding: 8px 20px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        z-index: 9999;
        opacity: 0;
        transition: all 0.3s ease;
    `;
    document.body.appendChild(toast);

    requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(-50%) translateY(0)';
    });

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(-50%) translateY(10px)';
        setTimeout(() => toast.remove(), 300);
    }, 2000);
}

function shakeElement(el) {
    el.style.animation = 'none';
    el.offsetHeight; // Reflow
    el.style.animation = 'shake 0.5s ease';
    el.style.borderColor = '#f87171';
    setTimeout(() => {
        el.style.borderColor = '';
        el.style.animation = '';
    }, 1000);
}

// Add shake animation dynamically
const shakeStyle = document.createElement('style');
shakeStyle.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        20% { transform: translateX(-6px); }
        40% { transform: translateX(6px); }
        60% { transform: translateX(-4px); }
        80% { transform: translateX(4px); }
    }
`;
document.head.appendChild(shakeStyle);

// Focus input on load
inputText.focus();
