// Content Script - Inject translation icons near text fields AND selected text
let currentTooltip = null;
let activeElement = null;
let selectionButton = null;
let selectedText = '';

// Create floating translate button for text inputs
function createTranslateButton() {
    const button = document.createElement('div');
    button.className = 'auto-translate-btn';
    button.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>';
    button.title = 'Translate (Click or Ctrl+Shift+T)';

    button.addEventListener('mousedown', async (e) => {
        if (e.button !== 0) return; // Only left click
        e.preventDefault();
        e.stopPropagation();

        // Ensure we capture the text BEFORE focus might be lost
        if (activeElement) {
            await handleTranslation(activeElement);
        }
    });

    return button;
}

// Create floating translate button for selected text
function createSelectionButton() {
    const button = document.createElement('div');
    button.className = 'auto-translate-btn auto-translate-selection-btn';
    button.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>';
    button.title = 'Translate selected text';

    button.addEventListener('mousedown', async (e) => {
        if (e.button !== 0) return; // Only left click
        e.preventDefault();
        e.stopPropagation();
        await handleSelectionTranslation();
    });

    return button;
}

// Create translation result tooltip
function createTooltip(translatedText, x, y, showReplace = true) {
    // Remove existing tooltip
    removeTooltip();

    const tooltip = document.createElement('div');
    tooltip.className = 'auto-translate-tooltip';

    const actionButtons = showReplace ? `
    <button class="tooltip-replace">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
        Replace
    </button>
    <button class="tooltip-append">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
        Append
    </button>
  ` : '';

    tooltip.innerHTML = `
    <div class="tooltip-header">
      <span>Translation</span>
      <button class="tooltip-close">×</button>
    </div>
    <div class="tooltip-content">${translatedText}</div>
    <div class="tooltip-actions">
      <button class="tooltip-copy">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
        Copy
      </button>
      ${actionButtons}
    </div>
  `;

    document.body.appendChild(tooltip);

    // Smart Positioning - Detect boundaries to prevent clipping
    const tooltipRect = tooltip.getBoundingClientRect();
    const viewportHeight = window.innerHeight;
    const viewportWidth = window.innerWidth;
    const offset = 35; // Significant gap for premium "floated" look

    // Default to ABOVE the target (requested by user)
    // 'y' here is the top of the element passed from callers
    let finalTop = y + window.scrollY - tooltipRect.height - offset;
    let finalLeft = x + window.scrollX;

    // If it hits the TOP of the screen, flip it to BELOW
    if (finalTop < window.scrollY + 10) {
        finalTop = y + window.scrollY + offset + 15; // Extra padding if flipped
    }

    // Check if it goes off bottom edge (safety check)
    if (finalTop + tooltipRect.height > window.scrollY + viewportHeight - 10) {
        finalTop = window.scrollY + viewportHeight - tooltipRect.height - 20;
    }

    // Check right edge
    if (finalLeft + tooltipRect.width > viewportWidth - 10) {
        finalLeft = viewportWidth - tooltipRect.width - 20;
    }

    // Check left edge
    if (finalLeft < 10) finalLeft = 10;

    tooltip.style.top = `${finalTop}px`;
    tooltip.style.left = `${finalLeft}px`;

    // Event listeners
    tooltip.querySelector('.tooltip-close').addEventListener('click', removeTooltip);

    tooltip.querySelector('.tooltip-copy').addEventListener('click', () => {
        navigator.clipboard.writeText(translatedText);
        showNotification('Copied!');
    });

    if (showReplace) {
        // Replace button - Delete original, add translation
        tooltip.querySelector('.tooltip-replace').addEventListener('mousedown', (e) => {
            e.preventDefault(); // SUPER CRITICAL: Stop focus loss
            e.stopPropagation();
            if (activeElement) {
                injectText(activeElement, translatedText, true);
                showNotification('Replaced!');
                removeTooltip();
            }
        });

        // Append button - Keep original, add translation
        tooltip.querySelector('.tooltip-append').addEventListener('mousedown', (e) => {
            e.preventDefault(); // SUPER CRITICAL: Stop focus loss
            e.stopPropagation();
            if (activeElement) {
                injectText(activeElement, translatedText, false);
                showNotification('Appended!');
                removeTooltip();
            }
        });
    }

    currentTooltip = tooltip;
    return tooltip;
}

// Remove tooltip
function removeTooltip() {
    if (currentTooltip) {
        currentTooltip.remove();
        currentTooltip = null;
    }
}

/**
 * Robustly injects text into an element (supports WhatsApp, Gmail, etc.)
 * @param {HTMLElement} element - The target input or contenteditable
 * @param {string} text - The text to inject
 * @param {boolean} replace - Whether to replace existing text or append
 */
// Robustly injects text into an element
function injectText(element, text, replace) {
    if (!element) return;

    // 1. Force Focus
    element.focus();

    // 2. Prepare Selection
    if (replace) {
        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
            element.select();
        } else {
            // ContentEditable (WhatsApp, Gmail, etc.)
            const selection = window.getSelection();
            const range = document.createRange();
            range.selectNodeContents(element);
            selection.removeAllRanges();
            selection.addRange(range);
        }
    } else {
        // Append: Move to end
        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
            const len = element.value.length;
            element.setSelectionRange(len, len);
            if (element.value && element.value.trim().length > 0) text = ' ' + text;
        } else {
            const selection = window.getSelection();
            const range = document.createRange();
            range.selectNodeContents(element);
            range.collapse(false); // Collapse to end
            selection.removeAllRanges();
            selection.addRange(range);

            // Add space check for innerText
            const currentText = element.innerText || element.textContent || '';
            if (currentText.trim().length > 0) text = ' ' + text;
        }
    }

    // 3. Execute Command (Standard for Rich Text Editors)
    // execCommand is deprecated but the ONLY reliable way for WhatsApp Web
    let success = false;
    try {
        success = document.execCommand('insertText', false, text);
    } catch (e) {
        console.error('execCommand failed:', e);
    }

    // 4. NUCLEAR OPTION: Simulate Paste Event (Best for WhatsApp/React)
    if (!success || (element.innerText && !element.innerText.includes(text) && !element.value?.includes(text))) {
        try {
            const dataTransfer = new DataTransfer();
            dataTransfer.setData('text/plain', text);

            const pasteEvent = new ClipboardEvent('paste', {
                clipboardData: dataTransfer,
                bubbles: true,
                cancelable: true
            });

            element.dispatchEvent(pasteEvent);
            success = true;
        } catch (e) {
            console.error('Paste simulation failed:', e);
        }
    }

    // 5. Heavy Fallback (Direct DOM Manipulation + Event Triggering)
    if (!success) {
        // Direct value set
        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
            if (replace) element.value = text;
            else element.value += text;
        } else {
            // ContentEditable fallback
            if (replace) element.innerText = text;
            else element.innerText += text;
        }

        // Dispatch heavy events to force framework update
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));

        // Special React Hack for WhatsApp/Facebook
        // React tracks 'value' property descriptor
        try {
            const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
            if (nativeInputValueSetter) {
                nativeInputValueSetter.call(element, replace ? text : (element.value + text));
                element.dispatchEvent(new Event('input', { bubbles: true }));
            }
        } catch (e) { }
    }
}

// Remove selection button
function removeSelectionButton() {
    if (selectionButton) {
        selectionButton.remove();
        selectionButton = null;
    }
}

// Show notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'auto-translate-notification';
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => notification.remove(), 2000);
}

// Handle translation for text fields
async function handleTranslation(element) {
    if (!element) return;

    // Properly extract text based on element type
    let text = '';
    if (element.isContentEditable || element.getAttribute('contenteditable') === 'true') {
        // For contenteditable, get innerText (cleaner than textContent)
        text = element.innerText || element.textContent || '';
    } else if (element.value !== undefined) {
        // For input/textarea
        text = element.value || '';
    } else {
        // Fallback
        text = element.innerText || element.textContent || '';
    }

    // Clean and trim the text
    text = text.trim();

    if (!text || text === '') {
        showNotification('Please enter some text first');
        return;
    }

    // Show loading
    const loadingTooltip = document.createElement('div');
    loadingTooltip.className = 'auto-translate-tooltip loading';
    loadingTooltip.innerHTML = '<div class="tooltip-content">Translating...</div>';
    document.body.appendChild(loadingTooltip);

    const rect = element.getBoundingClientRect();
    // Default loading tooltip ABOVE
    loadingTooltip.style.top = `${rect.top + window.scrollY - 50}px`;
    loadingTooltip.style.left = `${rect.left + window.scrollX}px`;

    try {
        // Fetch tone setting
        chrome.storage.local.get(['settings'], async (result) => {
            const tone = (result.settings && result.settings.professionalMode) ? 'professional' : 'custom';

            const response = await chrome.runtime.sendMessage({
                action: 'translate',
                text: text,
                direction: 'auto',
                tone: tone
            });

            loadingTooltip.remove();

            if (response.success) {
                // Pass rect.top to position tooltip ABOVE by default
                createTooltip(response.translated, rect.left, rect.top, true);
            } else {
                showNotification('Translation failed: ' + response.error);
            }
        });
    } catch (error) {
        loadingTooltip.remove();
        showNotification('Error: ' + error.message);
    }
}

// Handle translation for selected text
async function handleSelectionTranslation() {
    if (!selectedText || selectedText.trim() === '') {
        showNotification('No text selected');
        return;
    }

    const selection = window.getSelection();
    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();

    // Show loading
    const loadingTooltip = document.createElement('div');
    loadingTooltip.className = 'auto-translate-tooltip loading';
    loadingTooltip.innerHTML = '<div class="tooltip-content">Translating...</div>';
    document.body.appendChild(loadingTooltip);

    loadingTooltip.style.top = `${rect.top + window.scrollY - 50}px`;
    loadingTooltip.style.left = `${rect.left + window.scrollX}px`;

    // Hide selection button during translation
    removeSelectionButton();

    try {
        // Fetch tone setting
        chrome.storage.local.get(['settings'], async (result) => {
            const tone = (result.settings && result.settings.professionalMode) ? 'professional' : 'custom';

            const response = await chrome.runtime.sendMessage({
                action: 'translate',
                text: selectedText.trim(),
                direction: 'auto',
                tone: tone
            });

            loadingTooltip.remove();

            if (response.success) {
                // Pass rect.top to position tooltip ABOVE
                createTooltip(response.translated, rect.left, rect.top, false);
            } else {
                showNotification('Translation failed: ' + response.error);
            }
        });
    } catch (error) {
        loadingTooltip.remove();
        showNotification('Error: ' + error.message);
    }
}

// Handle text selection
function handleTextSelection() {
    const selection = window.getSelection();
    const text = selection.toString().trim();

    // Remove previous selection button
    removeSelectionButton();

    // If no text selected or too short, don't show button
    if (!text || text.length < 1) {
        selectedText = '';
        return;
    }

    selectedText = text;

    // Get selection position
    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();

    // Create and position selection button
    selectionButton = createSelectionButton();
    document.body.appendChild(selectionButton);

    // Position button near the end of selection
    selectionButton.style.top = `${rect.top + window.scrollY - 40}px`;
    selectionButton.style.left = `${rect.right + window.scrollX + 5}px`;
}

// Attach translation button to text fields
function attachTranslateButton(element) {
    // Skip if already has button
    if (element.dataset.hasTranslateBtn) return;

    element.dataset.hasTranslateBtn = 'true';

    // Show button on focus OR mouseenter (proactive)
    const showButton = (e) => {
        activeElement = element;

        // Remove existing buttons of same type ONLY (allow selection button to coexist if different)
        document.querySelectorAll('.auto-translate-btn:not(.auto-translate-selection-btn)').forEach(btn => btn.remove());

        const button = createTranslateButton();
        document.body.appendChild(button);

        // Position button - Move 50px left from right edge to avoid Send button overlap
        const rect = element.getBoundingClientRect();
        button.style.top = `${rect.top + window.scrollY + (rect.height / 2) - 18}px`; // Centered vertically in field
        button.style.left = `${rect.right + window.scrollX - 50}px`;
    };

    element.addEventListener('focus', showButton);
    element.addEventListener('mouseenter', showButton);

    // Hide button on blur (with delay for clicking)
    element.addEventListener('blur', () => {
        setTimeout(() => {
            if (!document.activeElement?.classList?.contains('auto-translate-btn')) {
                document.querySelectorAll('.auto-translate-btn:not(.auto-translate-selection-btn)').forEach(btn => btn.remove());
            }
        }, 200);
    });
}

// Find all text input fields
function findTextFields() {
    const selectors = [
        'input[type="text"]',
        'input[type="search"]',
        'input:not([type])',
        'textarea',
        '[contenteditable="true"]',
        '[role="textbox"]'
    ];

    const elements = document.querySelectorAll(selectors.join(', '));
    elements.forEach(element => attachTranslateButton(element));
}

// Initialize on page load
function init() {
    findTextFields();

    // Watch for dynamically added fields (WhatsApp, Gmail, etc.)
    const observer = new MutationObserver(() => {
        findTextFields();
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Listen for text selection
    document.addEventListener('mouseup', () => {
        setTimeout(handleTextSelection, 10);
    });

    document.addEventListener('keyup', () => {
        setTimeout(handleTextSelection, 10);
    });

    // Remove selection button when clicking elsewhere
    document.addEventListener('mousedown', (e) => {
        if (selectionButton && !selectionButton.contains(e.target)) {
            // Delay to allow click on button
            setTimeout(() => {
                const selection = window.getSelection();
                if (!selection.toString().trim()) {
                    removeSelectionButton();
                }
            }, 100);
        }
    });

    // Keyboard shortcut: Ctrl+Shift+T
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.shiftKey && e.key === 'T') {
            e.preventDefault();
            if (activeElement) {
                handleTranslation(activeElement);
            } else if (selectedText) {
                handleSelectionTranslation();
            }
        }
    });

    // Click outside to close tooltip
    document.addEventListener('click', (e) => {
        if (currentTooltip && !currentTooltip.contains(e.target)) {
            removeTooltip();
        }
    });
}

// Start when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

console.log('Auto Translate Extension - Content script loaded with text selection!');
