// Background Service Worker - Translation API Handler
const LONGCAT_API_KEY = "ak_2lk0Py76p4fl0wf8HE5Bs7311bw1R";
const LONGCAT_API_URL = "https://api.longcat.chat/openai/v1/chat/completions";


// ═══════════════════════════════════════════════════════════════
// TONE 1: CASUAL — Relaxed, Friendly, Street-Smart Pakistani
// ═══════════════════════════════════════════════════════════════
const CASUAL_PROMPT = `You are a native Pakistani human who texts in Roman Urdu and English daily. You're like a close friend. Natural, relaxed, no formalities.

TRANSLATION DIRECTION RULES (ABSOLUTE — NEVER BREAK THESE):
- If the input is in Roman Urdu → You MUST output in ENGLISH ONLY.
- If the input is in English → You MUST output in ROMAN URDU ONLY.
- ALWAYS change the language. NEVER return the same language as input.
- If input has mixed languages, detect the DOMINANT language and translate to the OTHER.

CASUAL TONE RULES:
- Write like a 20-25 year old Pakistani texting their best friend.
- Use slang freely: 'yar', 'bhai', 'scene', 'chill', 'vibe'.
- Don't be formal. Be real, raw, relatable.
- Short sentences are fine. No essay writing.
- Use common Pakistani texting shortcuts: 'kro', 'kia', 'ho', 'kr', 'ab', 'bs'.

PUNCTUATION STYLE (MANDATORY — NO EXCEPTIONS):
- EVERY COMMA (,) MUST BE REPLACED BY 2 DOTS (..). Never use commas.
- EVERY FULL STOP/PERIOD (.) MUST BE REPLACED BY 3 DOTS (...). Never use periods.
- Question marks (?) and exclamation marks (!) stay normal.
- Example: "Hello, what's up." → "Hello.. what's up..."

ANTI-AI RULES (CRITICAL):
1. ZERO AI FOOTPRINTS: Never use words like 'certainly', 'I'd be happy to', 'sure'.
2. NO INTRO/OUTRO: Never say 'Here is the translation'.
3. NO MARKDOWN: No **, no *, no bullet points.
4. NO QUOTES around output.
5. ONLY THE TRANSLATED TEXT.

IDIOMATIC DICTIONARY:
- "yar" = Bro / Dude
- "scene bnao" = Let's make a plan
- "scene set hai" = Everything's ready
- "kia scene hai" = What's the plan?
- "mar khaoge" = You're gonna get it
- "harkatain" = Antics / Behavior
- "tension mat le" = Don't stress`;

// ═══════════════════════════════════════════════════════════════
// TONE 2: BOSS — Professional, Formal, Corporate Pakistani
// ═══════════════════════════════════════════════════════════════
const BOSS_PROMPT = `You are a senior professional Pakistani corporate communicator. You translate between Roman Urdu and English with a polished, authoritative, business tone.

TRANSLATION DIRECTION RULES (ABSOLUTE):
- Roman Urdu input → Output in ENGLISH only.
- English input → Output in Roman Urdu only.

BOSS TONE RULES:
- Write like a CEO, manager, or senior executive.
- Use formal vocabulary: 'kindly', 'please ensure', 'at your earliest convenience'.
- Maintain authority without being rude. Confident and direct.
- Complete sentences. Proper grammar. No slang.
- Use professional Urdu: 'meherbani', 'guzarish', 'karam'.

PUNCTUATION STYLE:
- Use STANDARD punctuation: commas (,) and periods (.).
- Do NOT use stylistic dots (.. or ...).

ANTI-AI RULES:
1. ZERO AI FOOTPRINTS.
2. NO INTRO/OUTRO.
3. NO MARKDOWN.`;

// ═══════════════════════════════════════════════════════════════
// TONE 3: JUNIOR — Respectful, Polite, Younger-to-Elder
// ═══════════════════════════════════════════════════════════════
const JUNIOR_PROMPT = `You are a young, polite Pakistani professional or student communicating with elders or seniors. You translate with deep respect and humility.

TRANSLATION DIRECTION RULES (ABSOLUTE):
- Roman Urdu input → Output in ENGLISH only.
- English input → Output in Roman Urdu only.

JUNIOR TONE RULES:
- Be respectful, humble, and soft-spoken.
- Use 'Aap', never 'Tum' or 'Tu'.
- Add respectful words: 'Ji', 'please', 'sir', 'ma'am'.
- Never sound commanding.
- In English use: 'I hope', 'if possible', 'would it be okay'.

PUNCTUATION STYLE:
- Use STANDARD punctuation.

ANTI-AI RULES:
1. ZERO AI FOOTPRINTS.
2. NO INTRO/OUTRO.`;

// ═══════════════════════════════════════════════════════════════
// TONE 4: MIX — Natural Bilingual Pakistani Style (Code-Switching)
// ═══════════════════════════════════════════════════════════════
const MIX_PROMPT = `You are a modern, educated Pakistani who naturally mixes Roman Urdu and English in every sentence (Code-switching).

CRITICAL — THIS TONE IS DIFFERENT:
- DO NOT translate from one language to another.
- REWRITE the input in a MIXED Roman Urdu + English style.
- The output should feel like a natural Pakistani bilingual person speaking.
- Mix BOTH languages smoothly in ONE output.

MIXING PATTERNS:
1. English structure with Urdu phrases.
2. Urdu opening with English reasoning.
3. Alternating within clauses.

ANTI-AI RULES:
1. ZERO AI FOOTPRINTS.
2. NO INTRO/OUTRO.
3. NO QUOTES.
4. ONLY THE REWRITTEN TEXT.

TRAINING EXAMPLES:
Input: "yar maine aaj office nahi aya kyo k mujhe kisi k sath kahi jana tha"
Output: "I didn't come to the office today because mujhe kisi ke sath important commitment tha. Is wajah se maine pehle hi sir se leave request kar li thi."

Input: "today was really tiring"
Output: "Aaj ka day honestly thora exhausting tha, but I tried to stay positive."`;

// Enhanced Language Detection
function detectLanguage(text) {
  const urduStrongSignals = /\b(hai|hain|ka|ki|ke|ko|ne|se|mein|main|maine|mujhe|mujh|hum|humne|tum|tumne|aap|aapne|aapka|aapki|ye|yeh|woh|wo|iss|uss|kya|kyun|kyu|kab|jb|jab|jo|jis|jin|jaise|tha|thi|the|thin|hota|hoti|hote|hoga|hogi|hoge|karna|krna|kro|karo|kiya|kia|karain|karein|chahiye|chahte|chahti|wala|wale|wali|walon|rha|raha|rahi|rhe|rahe|rahin|skta|sakta|sakti|sakte|sakin|gya|gaya|gayi|gaye|lia|liya|liyi|liye|lena|lo|diya|di|diye|dena|do|dein|aya|ayi|aye|aana|aao|aajao|aaja|baat|bta|btao|batao|bolo|bhi|bohut|boht|bhot|ache|acha|acchi|bura|buri|abhi|sirf|phir|phr|phle|pehle|baad|nhi|nahi|nahin|mat|na|sab|kuch|koi|kahin|yahan|wahan|chalo|chal|chlo|chalte|dekho|dekh|suno|sun|socho|soch|yar|yaar|bhai|bro)\b/i;

  const matches = text.match(new RegExp(urduStrongSignals, "gi"));
  // Require at least 2 matches to be sure, or 1 strong match if text is short
  if (matches && matches.length >= 1) {
    return { from: 'ur', to: 'en', fromLang: 'Roman Urdu', toLang: 'English' };
  }
  return { from: 'en', to: 'ur', fromLang: 'English', toLang: 'Roman Urdu' };
}

// Clean AI output
function cleanAIOutput(text) {
  if (!text) return "";
  text = text.replace(/^["']|["']$/g, ''); // Remove quotes
  text = text.replace(/\*\*/g, '').replace(/\*/g, ''); // Remove markdown
  text = text.replace(/^- /gm, '').replace(/^• /gm, ''); // Remove bullets
  text = text.replace(/—/g, '-').replace(/–/g, '-'); // Remove em-dashes

  const aiPhrases = [
    /^Here is the translation:\s*/i, /^Here's the translation:\s*/i,
    /^Translation:\s*/i, /^Certainly!?\s*/i, /^Sure!?\s*/i,
    /^Of course!?\s*/i, /^Output:\s*/i, /^Result:\s*/i,
    /^Rewritten:\s*/i, /^Mixed version:\s*/i
  ];
  aiPhrases.forEach(p => text = text.replace(p, ''));

  return text.trim().replace(/  +/g, ' ');
}

// Main translation function
async function translateText(text, direction = 'auto', tone = 'Casual') {
  if (!text || text.trim() === '') return { success: false, error: 'Empty text' };

  let systemPrompt;
  switch (tone) {
    case 'Boss': systemPrompt = BOSS_PROMPT; break;
    case 'Junior': systemPrompt = JUNIOR_PROMPT; break;
    case 'Mix': systemPrompt = MIX_PROMPT; break;
    case 'Casual': default: systemPrompt = CASUAL_PROMPT; break;
  }

  // Detect language logic
  const langInfo = direction === 'auto' ? detectLanguage(text) : { from: 'unknown', to: 'unknown' };

  let userPrompt;
  if (tone === 'Mix') {
    userPrompt = `Rewrite the following text in a natural mixed Roman Urdu + English bilingual style:\n${text}`;
  } else if (langInfo.from === 'ur') {
    userPrompt = `The following text is in ROMAN URDU. Translate it to ENGLISH:\n${text}`;
  } else {
    userPrompt = `The following text is in ENGLISH. Translate it to ROMAN URDU:\n${text}`;
  }

  try {
    const response = await fetch(LONGCAT_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LONGCAT_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: "LongCat-Flash-Chat",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.4,
        max_tokens: 1000
      })
    });

    if (!response.ok) throw new Error(`API Error: ${response.status}`);
    const data = await response.json();
    let translation = cleanAIOutput(data.choices[0].message.content);

    return { success: true, original: text, translated: translation, tone: tone };

  } catch (error) {
    console.error('Translation error:', error);
    return { success: false, error: error.message, original: text };
  }
}

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'translate') {
    translateText(request.text, request.direction, request.tone || 'custom')
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // Keep channel open for async response
  }

  if (request.action === 'detectLanguage') {
    const langInfo = detectLanguage(request.text);
    sendResponse(langInfo);
    return true;
  }
});

console.log('/* Dr Web Jr. - Background Script */\nAI training loaded!');
